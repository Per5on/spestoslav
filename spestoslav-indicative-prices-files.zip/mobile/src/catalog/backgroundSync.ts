import AsyncStorage from "@react-native-async-storage/async-storage";
import * as BackgroundTask from "expo-background-task";
import * as TaskManager from "expo-task-manager";
import { Platform } from "react-native";
import { SIMULATION_MODE } from "../api";
import { savedListKey } from "../localData";
import { syncCatalogs } from "./catalogData";

const taskName = "spestovnik-catalog-sync";
const enabled = Platform.OS === "android" && !SIMULATION_MODE;

if (enabled) {
  TaskManager.defineTask(taskName, async () => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 40000);
    try {
      const raw = await AsyncStorage.getItem(savedListKey);
      const locality = raw ? JSON.parse(raw)?.locality?.id : undefined;
      const ok = await syncCatalogs(typeof locality === "string" ? locality : undefined, controller.signal);
      return ok ? BackgroundTask.BackgroundTaskResult.Success : BackgroundTask.BackgroundTaskResult.Failed;
    } catch {
      return BackgroundTask.BackgroundTaskResult.Failed;
    } finally {
      clearTimeout(timer);
    }
  });
}

// Android decides the exact time; a fixed hour cannot be requested, only a minimum interval.
const syncMinutes = 12 * 60;
const intervalKey = "spestovnik-catalog-sync-minutes";

export async function enableCatalogSync() {
  if (!enabled || !await TaskManager.isAvailableAsync()) return;
  if (await BackgroundTask.getStatusAsync() !== BackgroundTask.BackgroundTaskStatus.Available) return;
  const registered = await TaskManager.isTaskRegisteredAsync(taskName);
  const current = await AsyncStorage.getItem(intervalKey).catch(() => null);
  if (registered && current === String(syncMinutes)) return;
  // Builds before this one registered a 60-minute job; replace it once.
  if (registered) await BackgroundTask.unregisterTaskAsync(taskName);
  await BackgroundTask.registerTaskAsync(taskName, { minimumInterval: syncMinutes });
  await AsyncStorage.setItem(intervalKey, String(syncMinutes)).catch(() => undefined);
}
