const assert = require("node:assert/strict");
const fs = require("node:fs");
const ts = require("typescript");

function load(name, dependencies) {
  const code = ts.transpileModule(fs.readFileSync("src/catalog/" + name + ".ts", "utf8"), {
    compilerOptions: { module: ts.ModuleKind.CommonJS },
  }).outputText;
  const exports = {};
  new Function("exports", "require", code)(exports, name => dependencies[name]);
  return exports;
}

const saved = new Map();
const storage = {
  getItem: async key => saved.get(key) ?? null,
  setItem: async (key, value) => saved.set(key, value),
  removeItem: async key => saved.delete(key),
  multiRemove: async keys => keys.forEach(key => saved.delete(key)),
};
const storageModule = { default: storage };
const scope = { category: "fuel", localityId: "sofia" };
const price = {
  product_id: "a95", branch_id: "sofia-1", price_eur: 1.31, verified_at: new Date().toISOString(),
  expires_at: new Date(Date.now() + 60000).toISOString(),
};
const offer = {
  product_id: "a95", retailer_code: "chain", price_eur: "1.31",
  valid_until: price.expires_at, price_scope: "NATIONAL_ONLINE",
};
const station = { id: "sofia-1", address: "Test address", retailer_name: "Test", retailer_code: "chain" };
const paths = [];
let fetchResult = async path => path.includes("stores?") ? [station] :
  path.includes("national-offers?") ? [offer] : [price];
const mockApi = {
  API_BASE_URL: "https://fixture.invalid",
  httpStatus: error => error.status ?? null,
  api: async path => {
    paths.push(path);
    if (path.startsWith("/api/v1/fuel-snapshot?")) throw Object.assign(new Error("HTTP 404"), { status: 404 });
    return fetchResult(path);
  },
};
const modules = { "@react-native-async-storage/async-storage": storageModule, "../api": mockApi };
const catalogue = load("catalogData", { ...modules, "./cache": load("cache", modules) });

(async () => {
  const signal = new AbortController().signal;
  const { pricesResource, storesResource, onlineResource, clearLocalCatalogs } = catalogue;
  await pricesResource.load(scope, signal);
  await storesResource.load(scope, signal);
  await onlineResource.load(scope, signal);

  let cached;
  let respond;
  fetchResult = () => new Promise(resolve => { respond = resolve; });
  const before = paths.length;
  const first = pricesResource.load(scope, signal, true, rows => { cached = rows; });
  const second = pricesResource.load(scope, signal, true);
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(cached, [price]);
  assert.equal(paths.length - before, 1);
  const replacement = { ...price, price_eur: 1.43 };
  respond([replacement]);
  assert.deepEqual(await Promise.all([first, second]), [[replacement], [replacement]]);

  fetchResult = async () => { throw new Error("Server unreachable"); };
  cached = undefined;
  await assert.rejects(pricesResource.load({ ...scope, localityId: "plovdiv" }, signal, false,
    rows => { cached = rows; }), /unreachable/);
  assert.equal(cached, undefined);

  await assert.rejects(pricesResource.load(scope, signal, true, rows => { cached = rows; }), /unreachable/);
  assert.deepEqual(cached, [replacement]);
  const onlineKey = Array.from(saved.keys()).find(key => key.endsWith(":online:fuel"));
  const expired = JSON.parse(saved.get(onlineKey));
  expired.rows[0].valid_until = "2020-01-01";
  saved.set(onlineKey, JSON.stringify(expired));
  await assert.rejects(onlineResource.load(scope, signal, false, rows => { cached = rows; }), /unreachable/);
  assert.deepEqual(cached, []);

  await clearLocalCatalogs();
  assert.equal(saved.size, 0);

  // Grocery and technology prices are indicative: the cached copy loads whatever its expiry (for up
  // to 30 days) and is refreshed only once per 24 hours. Fuel keeps its short, strict cycle.
  const hour = 3600000;
  const cacheKey = (slot, category) => "spestovnik-local-catalog-v1:https://fixture.invalid:" + slot + ":" + category;
  const seed = (slot, category, ageMs, rows) => saved.set(cacheKey(slot, category), JSON.stringify({
    localityId: "sofia", savedAt: Date.now() - ageMs, rows,
  }));
  const oldOffer = { ...offer, valid_until: "2020-01-01T00:00:00Z" };
  const oldPrice = { ...price, expires_at: "2020-01-01T00:00:00.000Z" };
  const grocery = { category: "groceries", localityId: "sofia" };
  fetchResult = async () => { throw new Error("Server unreachable"); };
  paths.length = 0;
  seed("online", "groceries", hour, [oldOffer]);
  seed("prices", "groceries", hour, [oldPrice]);
  assert.deepEqual(await onlineResource.load(grocery, signal), [oldOffer]);
  assert.deepEqual(await pricesResource.load(grocery, signal), [oldPrice]);
  assert.equal(paths.length, 0, "a cache younger than 24 hours needs no request");
  seed("online", "groceries", 3 * 24 * hour, [oldOffer]);
  cached = undefined;
  await assert.rejects(onlineResource.load(grocery, signal, false, rows => { cached = rows; }), /unreachable/);
  assert.deepEqual(cached, [oldOffer], "an older cache is shown at once while it refreshes");
  seed("online", "groceries", 40 * 24 * hour, [oldOffer]);
  cached = undefined;
  await assert.rejects(onlineResource.load(grocery, signal, false, rows => { cached = rows; }), /unreachable/);
  assert.equal(cached, undefined, "a cache older than 30 days is not used");
  seed("online", "fuel", hour, [oldOffer]);
  cached = undefined;
  await assert.rejects(onlineResource.load(scope, signal, false, rows => { cached = rows; }), /unreachable/);
  assert.deepEqual(cached, [], "fuel offers still drop out when they expire");
  seed("online", "fuel", 11 * 60000, [{ ...offer, valid_until: new Date(Date.now() + 60000).toISOString() }]);
  paths.length = 0;
  await assert.rejects(onlineResource.load(scope, signal), /unreachable/);
  assert.equal(paths.length > 0, true, "fuel refreshes after 10 minutes");
  await clearLocalCatalogs();

  let task;
  let registered;
  let registrations = 0;
  let unregistrations = 0;
  const product = { id: "a95", name: "A95", category_code: "fuel", fuel_type: "petrol" };
  saved.set("saved-locality", JSON.stringify({ locality: { id: "sofia" } }));
  fetchResult = async path => {
    if (path.includes("products?")) return [product];
    if (path.includes("/catalog/")) return { schema_version: 1, products: [] };
    if (path.includes("stores?")) return [station];
    return path.includes("national-offers?") ? [offer] : [price];
  };
  const background = load("backgroundSync", {
    ...modules, "react-native": { Platform: { OS: "android" } },
    "expo-task-manager": {
      defineTask: (_name, perform) => { task = perform; },
      isAvailableAsync: async () => true,
      isTaskRegisteredAsync: async () => Boolean(registered),
    },
    "expo-background-task": {
      getStatusAsync: async () => 2, BackgroundTaskStatus: { Available: 2 },
      BackgroundTaskResult: { Success: 1, Failed: 2 },
      registerTaskAsync: async (name, options) => { registered = { name, ...options }; registrations += 1; },
      unregisterTaskAsync: async () => { registered = undefined; unregistrations += 1; },
    },
    "../localData": { savedListKey: "saved-locality" }, "./catalogData": catalogue,
  });
  await background.enableCatalogSync();
  assert.deepEqual(registered, { name: "spestovnik-catalog-sync", minimumInterval: 720 });
  await background.enableCatalogSync();
  assert.deepEqual([registrations, unregistrations], [1, 0], "an up-to-date job is left alone");
  saved.set("spestovnik-catalog-sync-minutes", "60"); // a build that scheduled the old 60-minute job
  await background.enableCatalogSync();
  assert.deepEqual([registrations, unregistrations], [2, 1], "the old job is replaced once");
  assert.deepEqual(registered, { name: "spestovnik-catalog-sync", minimumInterval: 720 });
  paths.length = 0;
  assert.equal(await task(), 1);
  assert.equal(paths.length, 12);
  assert.equal(paths.filter(path => path.includes("locality_id=sofia")).length, 9);
  assert(Array.from(saved.values()).some(value => value.includes('"fuel_type":"petrol"')));
  console.log("Catalogue sync checks passed: scoped first paint, shared reads, outage fallback, offer expiry, local reset and scheduled Android task.");
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
