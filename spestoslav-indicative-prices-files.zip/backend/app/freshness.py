"""How long last-known indicative prices stay visible after their stated expiry.

Grocery and technology prices are indicative figures copied from original online
sources and are not re-checked, so the latest known price stays visible for
STALE_PRICE_MAX_AGE_DAYS (default 90; 0 restores the strict "hide when expired" rule).
Fuel prices change quickly and always keep the strict rule.
"""

import os
from datetime import timedelta

from sqlalchemy import and_, or_

DEFAULT_STALE_DAYS = 90


def stale_price_days():
    try:
        return max(0, int(os.getenv("STALE_PRICE_MAX_AGE_DAYS", str(DEFAULT_STALE_DAYS))))
    except ValueError:
        return DEFAULT_STALE_DAYS


def still_shown(expiry_ok, timestamp, now, *, category=None, category_column=None):
    """`expiry_ok` or (not fuel and `timestamp` is recent enough).

    Pass `category_column` inside a query that spans categories, or a plain `category`
    string when the category is already known.
    """
    days = stale_price_days()
    if not days:
        return expiry_ok
    recent = timestamp > now - timedelta(days=days)
    if category_column is not None:
        return or_(expiry_ok, and_(category_column != "fuel", recent))
    return expiry_ok if category == "fuel" else or_(expiry_ok, recent)
