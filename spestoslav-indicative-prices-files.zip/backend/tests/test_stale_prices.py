"""Last-known indicative grocery/technology prices stay visible; fuel stays strict."""

import uuid
from decimal import Decimal
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select, update

import test_locality_search as fixtures
from app.db import get_db
from app.freshness import still_shown
from app.main import app
from app.marketplace import CurrentPrice, Promotion
from app.models import Category, Locality, Product, Retailer, StoreBranch
from app.workflows import NationalOffer


@pytest.fixture(autouse=True)
def database():
    previous = dict(app.dependency_overrides)
    fixtures.setup_function()
    app.dependency_overrides[get_db] = fixtures.override_get_db
    yield
    fixtures.teardown_function()
    app.dependency_overrides.clear()
    app.dependency_overrides.update(previous)


def age_prices(days_since_check, days_expired):
    now = datetime.now(timezone.utc)
    with fixtures.TestingSessionLocal() as db:
        db.execute(
            update(CurrentPrice).values(
                verified_at=now - timedelta(days=days_since_check),
                expires_at=now - timedelta(days=days_expired),
            )
        )
        db.commit()


def prices():
    return fixtures.client.get("/api/v1/prices/current").json()


def test_expired_grocery_price_stays_visible_by_default():
    age_prices(days_since_check=2, days_expired=1)
    assert [row["price_eur"] for row in prices()] == [1.25]


def test_stale_grocery_price_disappears_after_the_cutoff(monkeypatch):
    age_prices(days_since_check=100, days_expired=99)
    assert prices() == []
    age_prices(days_since_check=60, days_expired=59)
    assert len(prices()) == 1
    monkeypatch.setenv("STALE_PRICE_MAX_AGE_DAYS", "30")
    assert prices() == []


def test_zero_restores_strict_expiry(monkeypatch):
    age_prices(days_since_check=2, days_expired=1)
    monkeypatch.setenv("STALE_PRICE_MAX_AGE_DAYS", "0")
    assert prices() == []


def add_fuel_price(expired):
    now = datetime.now(timezone.utc)
    with fixtures.TestingSessionLocal() as db:
        locality = db.scalar(select(StoreBranch.locality_id))
        db.add(Category(code="fuel", name_bg="Гориво", name_en="Fuel"))
        db.flush()
        db.add(Retailer(code="PUMP", name="Pump", category_code="fuel"))
        product, branch = uuid.uuid4(), uuid.uuid4()
        db.add(
            Product(
                id=product, category_code="fuel", name="Petrol", normalized_name="petrol",
            )
        )
        db.flush()
        db.add(
            StoreBranch(id=branch, retailer_code="PUMP", locality_id=locality, address="Pump 1")
        )
        db.flush()
        db.add(
            CurrentPrice(
                product_id=product, branch_id=branch, price_eur=1.5, source="TEST",
                verified_at=now - timedelta(hours=2),
                expires_at=now - timedelta(hours=1) if expired else now + timedelta(hours=1),
            )
        )
        db.commit()


def test_fuel_keeps_the_strict_expiry_rule():
    add_fuel_price(expired=True)
    assert [row["price_eur"] for row in prices()] == [1.25]  # grocery only
    fuel = fixtures.client.get("/api/v1/prices/current", params={"category_code": "fuel"})
    assert fuel.json() == []


def test_unexpired_fuel_price_is_still_returned():
    add_fuel_price(expired=False)
    fuel = fixtures.client.get("/api/v1/prices/current", params={"category_code": "fuel"})
    assert [row["price_eur"] for row in fuel.json()] == [1.5]


def offer_rows(**filters):
    return fixtures.client.get("/api/v1/national-offers", params=filters).json()


def add_offer(valid_for_days, observed_days_ago, product_id=None):
    now = datetime.now(timezone.utc)
    with fixtures.TestingSessionLocal() as db:
        product = product_id or db.scalar(select(Product.id).where(Product.category_code == "FOOD"))
        db.add(
            NationalOffer(
                product_id=product, retailer_code="TEST", price_eur="2.00",
                source_reference="https://retailer.example/p",
                observed_at=now - timedelta(days=observed_days_ago),
                verified_at=now - timedelta(days=observed_days_ago),
                verified_by="test",
                valid_until=now + timedelta(days=valid_for_days),
            )
        )
        db.commit()


def test_expired_online_offer_stays_visible_and_newest_wins(monkeypatch):
    add_offer(valid_for_days=-3, observed_days_ago=10)
    add_offer(valid_for_days=-1, observed_days_ago=4)
    rows = offer_rows(category_code="FOOD")
    assert len(rows) == 1 and Decimal(rows[0]["price_eur"]) == Decimal("2")
    monkeypatch.setenv("STALE_PRICE_MAX_AGE_DAYS", "0")
    assert offer_rows(category_code="FOOD") == []


def test_online_offer_older_than_cutoff_is_hidden():
    add_offer(valid_for_days=-89, observed_days_ago=120)
    assert offer_rows(category_code="FOOD") == []


def test_comparison_includes_the_stale_online_offer_only_for_local_chains():
    add_offer(valid_for_days=-1, observed_days_ago=4)
    with fixtures.TestingSessionLocal() as db:
        db.execute(update(CurrentPrice).values(expires_at=datetime.now(timezone.utc) - timedelta(days=200),
                                               verified_at=datetime.now(timezone.utc) - timedelta(days=200)))
        db.execute(update(Promotion).values(ends_at=datetime.now(timezone.utc) - timedelta(days=1)))
        locality = str(db.scalar(select(StoreBranch.locality_id)))
        product = str(db.scalar(select(Product.id).where(Product.category_code == "FOOD")))
        db.commit()
    body = {"locality_id": locality, "items": [{"product_id": product}], "include_online": True}
    result = fixtures.client.post("/api/v1/baskets/compare", json=body).json()
    cheapest = result["cheapest"]
    assert cheapest["price_scope"] == "NATIONAL_ONLINE" and cheapest["retailer_code"] == "TEST"
    # Chains with no branch in the chosen place never appear, however recent their offer.
    with fixtures.TestingSessionLocal() as db:
        remote = Locality(source="TEST", source_id="elsewhere", name="Elsewhere")
        db.add(remote)
        db.commit()
        remote_id = str(remote.id)
    body["locality_id"] = remote_id
    assert fixtures.client.post("/api/v1/baskets/compare", json=body).json()["quotes"] == []


def test_helper_is_strict_for_fuel_and_open_for_others(monkeypatch):
    now = datetime.now(timezone.utc)
    expiry = CurrentPrice.expires_at.is_(None)
    verified = CurrentPrice.verified_at
    assert still_shown(expiry, verified, now, category="fuel") is expiry
    assert still_shown(expiry, verified, now, category="FOOD") is not expiry
    monkeypatch.setenv("STALE_PRICE_MAX_AGE_DAYS", "0")
    assert still_shown(expiry, verified, now, category="FOOD") is expiry
    monkeypatch.setenv("STALE_PRICE_MAX_AGE_DAYS", "bad")
    assert still_shown(expiry, verified, now, category="FOOD") is not expiry
